package main;

/**
 * Represents the money in game
 *
 */
public class Money {
	public static int money;
	
	/**
	 * returns the money
	 * @return money
	 */
	public static int getMoney() {
		return money;
	}
	/**
	 * sets the money
	 * @param newMoney the new money
	 */
	public static void setMoney(int newMoney) {
		money = newMoney;
	}
	/**
	 * Main method
	 * @param args
	 */
	public static void main(String[] args) {
		
	}
}
